

-- Windows Definition
MB_ICONASTERISK = 64 -- Type for MessageBeep()
SW_SHOWNORMAL = 1

-- Timer
BEEP_TIMER_ID = 1000

nobeep_mode = 0

local function vol_btn_icon(ismuted, init)
  if ismuted == 1 then
    if init then vol_btn.selected = 1 end
    vol_state.bkimage = "file='snd_mute.ico'"
  else
    if init then vol_btn.selected = 0 end
    local i = math.modf(vol_level / 33)
    i = i + 1
    if i > 3 then i = 3 end
    vol_state.bkimage = "file='snd_" .. i .. ".ico'"
  end
end

local function init_elem()
  vol_level = app:call('Volume::GetLevel')
  local mute = app:call('Volume::IsMuted')
  app:print(volume_slider)
  volume_slider.value = vol_level
  vol_value.text = vol_level
  vol_level = tonumber(vol_level)

  vol_btn_icon(mute, 1)

  need_beep = 0
  suilib.call('KillTimer', BEEP_TIMER_ID)
  suilib.call('SetTimer', BEEP_TIMER_ID, 500)
end

function onload()
  require('lua_helper.lua_helper')

  sui:find('vol_name').text = app:call('Volume::GetName')
  vol_value = sui:find('vol_value')
  volume_slider = sui:find('volume_slider')
  app:print(volume_slider)
  vol_btn = sui:find('vol_btn')
  vol_state = sui:find('vol_state')
  sui:find('sndvol_settings').text = sui:find('sndvol_settings').text

  if string.find(os.getenv('SUI_PARAM'), '-nobeep') then
    nobeep_mode = 1
  end

  ui_path = sui:jcfg('res_path')
  -- local sd = os.getenv("SystemDrive")
  -- if not File.exists(sd ..'\\Windows\\media\\Windows Background.wav') then
  --   app:run('xcopy', '"' .. ui_path .. 'Windows Background.wav" "' .. sd ..'\\Windows\\media\\"', 0)
  -- end
  LOADED = 1
  init_elem()
end

function onshow()
  if not LOADED then return end
  init_elem()
end

function onchanged(ctrl)
  if not LOADED then return end
  if ctrl == 'volume_slider' then
    local v = volume_slider.value
    local t = vol_value.text
    if tostring(v) ~= t then
      vol_value.text = v
      vol_level = v
      vol_changed = 1
      if v == 0 then
        vol_btn.selected = 1
      else
        vol_btn.selected = 0
      end
    end
  elseif ctrl == 'vol_btn' then
    local s = vol_btn.selected
    app:call('Volume::Mute', s)
  end
  vol_btn_icon(vol_btn.selected)
end

UISTATE_CAPTURED = 64 -- Drag & Drop - ing

function ontimer(id)
  if id == BEEP_TIMER_ID then
    if sui:ishidden() == 1 then -- no need watch the slider change
      suilib.call('KillTimer', BEEP_TIMER_ID)
    end
    if vol_changed == 1 then
      app:call('Volume::SetLevel', volume_slider.value)
      if nobeep_mode == 0 and app:call('band', volume_slider.state, UISTATE_CAPTURED) == 0 then
        -- app:call('Beep', MB_ICONASTERISK) -- Beep can't work in PE
        app:call('play', ui_path .. 'Windows Background.wav', 0)
        vol_changed = 0
      end
    end
  end
end

local function hideme()
  sui:hide()
  suilib.call('KillTimer', BEEP_TIMER_ID)
end

function onclick(ctrl)
  if ctrl == 'sndvol_settings' or ctrl == 'vol_value' then
    hideme()
    app:run('sndvol.exe', '-m 268439552', SW_SHOWNORMAL)
  elseif ctrl == 'closebtn' then
    hideme()
  end
end
