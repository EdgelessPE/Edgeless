
local function power_helper(wu_param, sd_param)
  require('lua_helper.io_helper')
  local sd = os.getenv("SystemDrive")
  if File.exists(sd ..'\\Windows\\System32\\Wpeutil.exe') then
    suilib.call('run', 'wpeutil.exe', wu_param, 0) -- SW_HIDE(0)
    return 0
  elseif File.exists(sd ..'\\Windows\\System32\\shutdown.exe') then
    suilib.call('run', 'shutdown.exe', sd_param .. ' -t 0')
    return 0
  end
  return 1
end

local function reboot()
    return power_helper('Reboot', '-r')
end

local function shutdown()
    return power_helper('Shutdown', '-s')
end

function onclick(ctrl)
  if ctrl == "restartbtn" then
    reboot()
  elseif ctrl == "shutdownbtn" then
    shutdown()
  end
end
