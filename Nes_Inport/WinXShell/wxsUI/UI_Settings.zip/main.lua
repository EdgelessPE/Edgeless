require('lua_helper.lua_helper')

cmdline = app:info('cmdline')
apppath = app:info('path')
fixscreen_opt = ''
if string.find(cmdline, '-fixscreen') then fixscreen_opt = '-fixscreen' end

RESTORE_TIMER_ID = 1000
AUTO_RESTORE_SEC = 15
display_restore_counter = AUTO_RESTORE_SEC

local function set_switch_with_text(elem, val, text_only)
  if text_only ~= true then elem.selected = val end
  if val == 1 then elem.text = "%{On}" else elem.text = "%{Off}" end
end

local function click_tab(name)
  sui:click(name)
end

local function init_display_settings()
  resolution_combo = sui:find('resolution_combo')
  rotate_combo = sui:find('rotate_combo')
  display_applybtn = sui:find('display_applybtn')
  display_restorebtn = sui:find('display_restorebtn')
  org_display_restorebtn_text = display_restorebtn.text -- save origin retore button text for retore timer

  click_tab('Nav_Display') -- be visible for changing combobox index

  resolution_combo.list = suilib.call('GetResolutionList')
  resolution_combo.index = suilib.call('GetCurrentResolution')

  rotate_combo.index = suilib.call('GetRotation')

  last_resolution = resolution_combo.text
  last_rotate = rotate_combo.index
end

local function init_colors_settings()
  local ct_name = 'dark'
  if System:GetSetting('AppsColorTheme') == 1 then ct_name = 'light' end
  local opt = sui:find('colortheme_' .. ct_name .. '_opt')
  opt.selected = 1
end

local function init_taskbar_settings()
  elm_taskbar_autohide = sui:find('chk_taskbar_autohide')
  elm_taskbar_smallicons = sui:find('chk_taskbar_smallicons')

  local onoff = Taskbar:GetSetting('AutoHide')
  set_switch_with_text(elm_taskbar_autohide, onoff)

  onoff = (Taskbar:GetSetting('TaskbarSmallIcons') or 0) | 0 -- to integer
  set_switch_with_text(elm_taskbar_smallicons, onoff)

  local glomlevel = (Taskbar:GetSetting('TaskbarGlomLevel') or 2) | 0
  local elm_combline_style_opt = sui:find('combine_style_' .. glomlevel)
  elm_combline_style_opt.selected = 1
end

local function init_settings()
  init_display_settings()
  init_colors_settings()
  init_taskbar_settings()
end

local function display_applybtn_click()
    suilib.call('KillTimer', RESTORE_TIMER_ID)

    last_resolution = resolution_combo.text
    last_rotate = rotate_combo.index

    resolution_combo.mouse = 'true'
    rotate_combo.mouse =  'true'
    display_applybtn.visible = 0
    display_restorebtn.visible = 0
end

local function switch_tab(name)
  local map = {
    'display',
    'background',
    'colors',
    'taskbar'
  }
  local tab = #map
  for i = 1, #map do
    if map[i] == name then tab = i; break end
  end

  if UI_Inited == 1 then
    if display_applybtn.visible == 1 then
      display_applybtn_click()
    end
  end
  tab_layout.selectedid = tab
end

function onload()
  UI_Inited = 0
  sui:find('quickaccess_label').text = sui:find('quickaccess_label').text  -- expand resource string
  sui:find('compmgmt_button').text = sui:find('compmgmt_button').text
  tab_layout = sui:find('TabLayoutMain')
  init_settings()
  if string.find(cmdline, '-display') then
    click_tab('Nav_Display')
  elseif string.find(cmdline, '-colors') then
    click_tab('Nav_Colors')
  else
    click_tab('Nav_Taskbar')
  end
  UI_Inited = 1
end

local function fixscreen()
    if fixscreen_opt ~= '' then
        app:call('Desktop::UpdateWallpaper')
        app:call('sleep', 200)
        app:call('Taskbar::ChangeNotify')
    end
end

local function display_restorebtn_click()
    suilib.call('KillTimer', RESTORE_TIMER_ID)
    suilib.call('SetResolution', last_resolution)
    suilib.call('SetRotation', last_rotate)
    fixscreen()
    resolution_combo.index = last_resolution
    rotate_combo.index = last_rotate

    resolution_combo.mouse = 'true'
    rotate_combo.mouse =  'true'
    display_applybtn.visible = 0
    display_restorebtn.visible = 0
end

local function nav_click(ctrl)
  local handled = true
  if ctrl == 'Nav_Display' then
    switch_tab('display')
  elseif ctrl == 'Nav_Background' then
    switch_tab('background')
  elseif ctrl == 'Nav_Colors' then
    switch_tab('colors')
  elseif ctrl == 'Nav_Taskbar' then
    switch_tab('taskbar')
  else
    handled = false
  end
  return handled
end

local function combine_style_click(ctrl)
  local handled = true
  if ctrl == 'combine_style_0' then
    Taskbar:CombineButtons('always')
  elseif ctrl == 'combine_style_1' then
    Taskbar:CombineButtons('auto')
  elseif ctrl == 'combine_style_2' then
    Taskbar:CombineButtons('never')
  else
    handled = false
  end
  return handled
end

local function nav_button_click(ctrl)
  local handled = true
  if ctrl == 'home_button' then
    app:run('control.exe')
  elseif ctrl == 'compmgmt_button' then
    app:run('compmgmt.msc')
  else
    handled = false
  end
  return handled
end

local function restart()
  --app:run(apppath .. '\\WinXShell.exe', '-luacode \"wxsUI(\'UI_Settings\', nil, \'-colors ' .. fixscreen_opt .. '\')\"')
  --app:run(apppath .. '\\WinXShell.exe', [[-console -luacode "wxsUI('UI_Settings','main.jcfg','-colors ]] .. fixscreen_opt .. [[')"]], 0) -- SW_HIDE
  wxsUI('UI_Settings','main.jcfg','-colors ' .. fixscreen_opt)
  suilib.close()
end

function onclick(ctrl)
  -- app:print('onclick:' .. ctrl)
  if nav_click(ctrl) then return end
  if combine_style_click(ctrl) then return end
  if nav_button_click(ctrl) then return end

  if ctrl == 'colortheme_light_opt' then
    System:ColorTheme('light')
    restart()
  elseif ctrl == 'colortheme_dark_opt' then
    System:ColorTheme('dark')
    restart()
  elseif ctrl == 'display_applybtn' then
      display_applybtn_click()
  elseif ctrl == 'display_restorebtn' then
    display_restorebtn_click()
  end
end

function onchanged(ctrl)
  local val = 0
  if UI_Inited == 0 then return end -- do nothing for init changing

  if ctrl == "resolution_combo" or ctrl == "rotate_combo" then
    if last_resolution ~= resolution_combo.text then val = 1 end
    if last_rotate ~= rotate_combo.index then val = 1 end
    if val == 0 then return end -- no change or restore

    suilib.call('SetResolution', resolution_combo.text)
    suilib.call('SetRotation', rotate_combo.index)
    fixscreen()
    -- set auto restore timer
    display_restore_counter = AUTO_RESTORE_SEC

    resolution_combo.mouse = 'false'
    rotate_combo.mouse =  'false'
    display_applybtn.visible = 1
    display_restorebtn.visible = 1

    display_restorebtn.text = string.format('[%d]%s', display_restore_counter, org_display_restorebtn_text)
    suilib.call('SetTimer', RESTORE_TIMER_ID, 1000)
    return
  end

  if ctrl == 'chk_taskbar_autohide' then
    val = elm_taskbar_autohide.selected
    set_switch_with_text(elm_taskbar_autohide, val, true)
    Taskbar:AutoHide(val)
  elseif ctrl == 'chk_taskbar_smallicons' then
    val = elm_taskbar_smallicons.selected
    set_switch_with_text(elm_taskbar_smallicons, val, true)
    Taskbar:UseSmallIcons(val)
  end
end

function ontimer(id)
    suilib.print('ontimer:' .. id)
    if (id == RESTORE_TIMER_ID) then
        display_restore_counter = display_restore_counter - 1
        display_restorebtn.text = string.format('[%d]%s', display_restore_counter, org_display_restorebtn_text)
        -- auto restore
        if (display_restore_counter <= 0) then
            display_restorebtn_click()
        end
    end
end
